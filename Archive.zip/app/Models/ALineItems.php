<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ALineItems extends Model
{
    use HasFactory;
    protected $guarded = [];
}
